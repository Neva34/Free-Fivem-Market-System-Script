let allItems = [];
let cartItems = [];
let currentCategory = 'all';



function openDialog(data) {
    if (data && data.items) {
        allItems = data.items;
    }

    const dialog = document.getElementById('npc-dialog');
    dialog.style.animation = 'none';
    dialog.offsetHeight; 
    dialog.style.animation = '';
    dialog.classList.remove('hidden');

    document.querySelectorAll('.chat-bubble').forEach((b, i) => {
        b.style.animation = 'none';
        b.offsetHeight;
        b.style.animation = '';
    });
    const opts = document.getElementById('dialog-options');
    if (opts) {
        opts.style.animation = 'none';
        opts.offsetHeight;
        opts.style.animation = '';
    }
}

function closeDialog() {
    const dialog = document.getElementById('npc-dialog');
    if (dialog.classList.contains('hidden')) return;

    dialog.style.animation = 'dialogFadeOut 0.25s ease forwards';

    setTimeout(() => {
        dialog.classList.add('hidden');
        dialog.style.animation = '';
    }, 260);

    fetch(`https://${GetParentResourceName()}/closeMenu`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    }).catch(() => {});
}

function chooseShop() {
    const dialog = document.getElementById('npc-dialog');
    dialog.style.animation = 'dialogFadeOut 0.25s ease forwards';

    setTimeout(() => {
        dialog.classList.add('hidden');
        dialog.style.animation = '';
        openMarket();
    }, 260);
}

function openMarket() {
    const menu = document.querySelector('.market-menu');
    if (menu) {
        menu.style.opacity = '0';
        menu.style.transform = 'scale(0.95)';
    }

    document.getElementById('market-container').classList.remove('hidden');

    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            if (menu) {
                menu.style.opacity = '1';
                menu.style.transform = 'scale(1)';
            }
        });
    });

    setCategory('all');
    updateCartUI();
    document.getElementById('search-input').value = '';
}



window.addEventListener('message', function(event) {
    const data = event.data;

    if (data.action === 'openDialog') {
        allItems = data.items || [];
        openDialog(data);
    } else if (data.action === 'openMenu') {
        allItems = data.items || [];
        openMarket();
    } else if (data.action === 'closeMenu') {
        closeUI();
        closeDialog();
    }
});


function setCategory(cat) {
    currentCategory = cat;

    document.querySelectorAll('.category-item').forEach(el => {
        el.classList.remove('active');
        if (el.dataset.category === cat) {
            el.classList.add('active');
        }
    });

    const titles = {
        'all': 'TÜM ÜRÜNLER',
        'food': 'YİYECEKLER',
        'drink': 'İÇECEKLER'
    };
    document.getElementById('current-category-title').textContent = titles[cat] || 'ÜRÜNLER';

    filterItems();
}



function filterItems() {
    const searchTerm = document.getElementById('search-input').value.toLowerCase();

    const filteredItems = allItems.filter(item => {
        const matchesSearch = item.label.toLowerCase().includes(searchTerm);
        const matchesCategory = currentCategory === 'all' || item.category === currentCategory;
        return matchesSearch && matchesCategory;
    });

    loadItems(filteredItems);
}

document.getElementById('search-input').addEventListener('input', filterItems);



function loadItems(items) {
    const container = document.getElementById('items-container');
    container.innerHTML = '';

    if (items.length === 0) {
        container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; color: #888; padding: 40px;">Ürün bulunamadı.</div>';
        return;
    }

    items.forEach((item, index) => {
        const itemCard = document.createElement('div');
        itemCard.className = 'item-card';
        itemCard.style.animationDelay = `${index * 0.05}s`;
        itemCard.onclick = () => addToCart(item.name);

        const qbUrl  = `nui://qb-inventory/html/images/${item.name}.png`;
        const oxUrl  = `nui://ox_inventory/web/images/${item.name}.png`;

        itemCard.innerHTML = `
            <div class="item-image-wrapper">
                <img src="${qbUrl}" alt="${item.label}" class="item-image" onerror="this.onerror=null; this.src='${oxUrl}';">
            </div>
            <div class="item-info">
                <h3>${item.label}</h3>
                <div class="price">$${item.price}</div>
            </div>
        `;

        container.appendChild(itemCard);
    });
}



function addToCart(itemName) {
    const itemData = allItems.find(i => i.name === itemName);
    if (!itemData) return;

    const existingItem = cartItems.find(i => i.name === itemName);

    if (existingItem) {
        if (existingItem.amount < 99) existingItem.amount += 1;
    } else {
        cartItems.push({ name: itemData.name, label: itemData.label, price: itemData.price, amount: 1 });
    }

    updateCartUI();
}

function removeFromCart(itemName) {
    const existingItem = cartItems.find(i => i.name === itemName);
    if (!existingItem) return;

    if (existingItem.amount > 1) {
        existingItem.amount -= 1;
    } else {
        cartItems = cartItems.filter(i => i.name !== itemName);
    }

    updateCartUI();
}

function deleteFromCart(itemName) {
    cartItems = cartItems.filter(i => i.name !== itemName);
    updateCartUI();
}

function clearCart() {
    cartItems = [];
    updateCartUI();
}

function updateCartUI() {
    const container = document.getElementById('cart-items-container');
    const checkoutBtn = document.getElementById('checkout-btn');
    const totalPriceEl = document.getElementById('cart-total-price');

    container.innerHTML = '';
    let total = 0;

    if (cartItems.length === 0) {
        container.innerHTML = '<div class="empty-cart">Sepetiniz boş</div>';
        checkoutBtn.disabled = true;
        totalPriceEl.textContent = '$0';
        return;
    }

    checkoutBtn.disabled = false;

    cartItems.forEach(item => {
        total += item.price * item.amount;

        const qbUrl = `nui://qb-inventory/html/images/${item.name}.png`;
        const oxUrl = `nui://ox_inventory/web/images/${item.name}.png`;

        const cartItemEl = document.createElement('div');
        cartItemEl.className = 'cart-item';
        cartItemEl.innerHTML = `
            <div class="cart-item-img">
                <img src="${qbUrl}" onerror="this.onerror=null; this.src='${oxUrl}';">
            </div>
            <div class="cart-item-info">
                <div class="cart-item-title">${item.label}</div>
                <div class="cart-item-price">$${item.price * item.amount}</div>
            </div>
            <div class="cart-item-controls">
                <button class="cart-btn" onclick="removeFromCart('${item.name}')">-</button>
                <span class="cart-item-amount">${item.amount}</span>
                <button class="cart-btn" onclick="addToCart('${item.name}')">+</button>
                <button class="cart-delete-btn" onclick="deleteFromCart('${item.name}')">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                </button>
            </div>
        `;

        container.appendChild(cartItemEl);
    });

    totalPriceEl.textContent = '$' + total;
}



let currentPaymentMethod = 'cash';

function setPayment(type) {
    currentPaymentMethod = type;
    document.getElementById('pay-cash').classList.remove('active');
    document.getElementById('pay-bank').classList.remove('active');
    document.getElementById(`pay-${type}`).classList.add('active');
}

function checkout() {
    if (cartItems.length === 0) return;

    fetch(`https://${GetParentResourceName()}/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cart: cartItems, paymentType: currentPaymentMethod })
    }).catch(() => {});

    closeUI();
}



function closeUI() {
    const menu = document.querySelector('.market-menu');
    if (menu) {
        menu.style.opacity = '0';
        menu.style.transform = 'scale(0.95)';
    }

    setTimeout(() => {
        document.getElementById('market-container').classList.add('hidden');
        cartItems = [];
        updateCartUI();
    }, 300);
}

function closeMenu() {
    closeUI();

    fetch(`https://${GetParentResourceName()}/closeMenu`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    }).catch(() => {});
}

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const dialog = document.getElementById('npc-dialog');
        const market = document.getElementById('market-container');

        if (!market.classList.contains('hidden')) {
            closeMenu();
        } else if (!dialog.classList.contains('hidden')) {
            closeDialog();
        }
    }
});

const style = document.createElement('style');
style.textContent = `
@keyframes dialogFadeOut {
    from { opacity: 1; transform: translateY(0); }
    to   { opacity: 0; transform: translateY(30px); }
}`;
document.head.appendChild(style);

