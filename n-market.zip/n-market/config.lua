Config = {}

--konum
Config.Markets = {
    {
        name = "24/7 Market - Grove Street",
        coords = vector3(24.4, -1347.43, 29.5),
        heading = 269.0,
        pedModel = "mp_m_shopkeep_01"
    },
    {
        name = "24/7 Market - Mirror Park",
        coords = vector3(1163.4, -323.8, 69.2),
        heading = 100.0,
        pedModel = "mp_m_shopkeep_01"
    },
    {
        name = "24/7 Market - Sandy Shores",
        coords = vector3(1961.1, 3740.0, 32.3),
        heading = 301.0,
        pedModel = "mp_m_shopkeep_01"
    },
    {
        name = "LTD Gasoline - Vespucci",
        coords = vector3(-707.5, -914.2, 19.2),
        heading = 90.0,
        pedModel = "mp_m_shopkeep_01"
    }
}
--itemler img ismi name ile aynı olsun
Config.Items = {
    {label = "Sandviç", name = "sandwich", price = 100, category = "food"},
    {label = "Çikoleyta", name = "snikkel_candy", price = 100, category = "food"},
    {label = "Kola", name = "cola", price = 75, category = "drink"},
    {label = "Bira", name = "beer", price = 75, category = "drink"},
    {label = "Kahve", name = "coffee", price = 80, category = "drink"}
}
