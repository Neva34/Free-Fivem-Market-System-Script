local ESX = nil
local QBCore = nil

if GetResourceState('es_extended') == 'started' then
    ESX = exports['es_extended']:getSharedObject()
elseif GetResourceState('qb-core') == 'started' then
    QBCore = exports['qb-core']:GetCoreObject()
end

RegisterServerEvent('market:checkout')
AddEventHandler('market:checkout', function(cart, paymentType)
    local src = source
    local totalCost = 0
    
    if paymentType ~= 'bank' then paymentType = 'cash' end
    
    for _, cartItem in ipairs(cart) do
        for _, configItem in ipairs(Config.Items) do
            if cartItem.name == configItem.name then
                totalCost = totalCost + (configItem.price * cartItem.amount)
                break
            end
        end
    end
    
    if totalCost <= 0 then return end

    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if not xPlayer then return end
        
        local hasEnough = false
        if paymentType == 'bank' then
            if xPlayer.getAccount('bank').money >= totalCost then
                xPlayer.removeAccountMoney('bank', totalCost)
                hasEnough = true
            end
        else
            if xPlayer.getMoney() >= totalCost then
                xPlayer.removeMoney(totalCost)
                hasEnough = true
            end
        end
        
        if hasEnough then
            for _, item in ipairs(cart) do
                xPlayer.addInventoryItem(item.name, item.amount)
            end
            TriggerClientEvent('esx:showNotification', src, 'Satın alma başarılı! Ödenen: ~g~$' .. totalCost .. ' (' .. (paymentType == 'bank' and 'Banka' or 'Nakit') .. ')')
        else
            TriggerClientEvent('esx:showNotification', src, '~r~Yeterli paranız yok!')
        end
        
    elseif QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if not Player then return end
        
        if Player.Functions.RemoveMoney(paymentType, totalCost, "market-buy") then
            for _, item in ipairs(cart) do
                Player.Functions.AddItem(item.name, item.amount)
            end
            TriggerClientEvent('QBCore:Notify', src, 'Satın alma başarılı! Ödenen: $' .. totalCost .. ' (' .. (paymentType == 'bank' and 'Banka' or 'Nakit') .. ')', 'success')
        else
            TriggerClientEvent('QBCore:Notify', src, 'Yeterli paranız yok!', 'error')
        end
    else
        print("^1[HATA] Ne ESX ne de QBCore algılanamadı.^7")
    end
end)
