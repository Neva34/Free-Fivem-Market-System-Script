local isMenuOpen = false
local spawnedPeds = {}

Citizen.CreateThread(function()
    for _, market in pairs(Config.Markets) do
        RequestModel(GetHashKey(market.pedModel))
        while not HasModelLoaded(GetHashKey(market.pedModel)) do
            Wait(1)
        end

        local ped = CreatePed(4, GetHashKey(market.pedModel), market.coords.x, market.coords.y, market.coords.z - 1.0, market.heading, false, true)
        SetEntityHeading(ped, market.heading)
        FreezeEntityPosition(ped, true)
        SetEntityInvincible(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)

        table.insert(spawnedPeds, ped)
    end
end)

Citizen.CreateThread(function()
    while true do
        local sleep = 500
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)

        for _, market in pairs(Config.Markets) do
            local distance = #(playerCoords - market.coords)

            if distance < 2.5 then
                sleep = 0
                DrawText3D(market.coords.x, market.coords.y, market.coords.z + 1.0, "[~g~E~w~] " .. market.name)

                if IsControlJustReleased(0, 38) and not isMenuOpen then 
                    OpenDialog()
                end
            end
        end

        Citizen.Wait(sleep)
    end
end)

function OpenDialog()
    isMenuOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = "openMenu",
        items = Config.Items
    })
end

RegisterNUICallback('closeMenu', function(data, cb)
    isMenuOpen = false
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('checkout', function(data, cb)
    isMenuOpen = false
    SetNuiFocus(false, false)
    TriggerServerEvent('market:checkout', data.cart, data.paymentType)
    cb('ok')
end)

function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)

    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
end

AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        for _, ped in pairs(spawnedPeds) do
            DeleteEntity(ped)
        end
    end
end)
